package de.duacafe.bootsplash;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import java.io.IOException;
import java.io.InputStream;

/** Shows the cafe logo for 3 seconds, then opens FLauncher. */
public final class SplashActivity extends Activity {
    private static final long DISPLAY_MS = 3000L;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final Runnable openHome = this::launchFLauncher;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN |
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        ImageView image = new ImageView(this);
        image.setScaleType(ImageView.ScaleType.FIT_CENTER);
        try (InputStream input = getAssets().open("duacafe_tv.png")) {
            Bitmap bitmap = BitmapFactory.decodeStream(input);
            image.setImageBitmap(bitmap);
        } catch (IOException ignored) {
            // Avoid leaving a blank activity indefinitely if the asset is damaged.
        }
        root.addView(image, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT,
                Gravity.CENTER));
        setContentView(root);
        mainHandler.postDelayed(openHome, DISPLAY_MS);
    }

    private void launchFLauncher() {
        Intent home = new Intent(Intent.ACTION_MAIN);
        home.addCategory(Intent.CATEGORY_HOME);
        home.setPackage("me.efesser.flauncher");
        home.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        try {
            startActivity(home);
        } catch (ActivityNotFoundException notInstalledOrDisabled) {
            Intent fallback = new Intent(Intent.ACTION_MAIN);
            fallback.addCategory(Intent.CATEGORY_HOME);
            fallback.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            try {
                startActivity(fallback);
            } catch (ActivityNotFoundException ignored) {
                // No home application available; still close the splash safely.
            }
        }
        finish();
    }

    @Override
    protected void onDestroy() {
        mainHandler.removeCallbacks(openHome);
        super.onDestroy();
    }
}
