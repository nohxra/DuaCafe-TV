package de.duacafe.bootsplash;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Starts the splash only after a real Android boot (not on normal standby wake). */
public final class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (!Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) return;
        Intent splash = new Intent(context, SplashActivity.class);
        splash.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        context.startActivity(splash);
    }
}
