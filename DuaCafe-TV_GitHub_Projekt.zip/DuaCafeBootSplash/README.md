# DuaCafé Boot Splash — Philips Android TV 8.0

Android 8.0 (API 26) compatible demo source project. On receipt of `BOOT_COMPLETED`, launches a fullscreen 1920x1080 DuaCafé image for three seconds, then opens FLauncher (`me.efesser.flauncher`) or the system default HOME application if FLauncher is unavailable.

- The original Philips logo and firmware are **not modified**.
- Normal standby wake does **not** emit BOOT_COMPLETED, so the splash is not intended to show then.
- Philips firmware can override / suppress startup apps; actual boot receiver behavior on this exact TV is **not verified**.
- Requires opening the app **once after installing** to clear Android's stopped state, and leaving auto-start enabled if TV has such an option.
- No root, no Internet permission, no ads, no tracking.

## Build

Requires Android Studio / Android SDK and Gradle 8.7; JDK 17. Run `gradle assembleDebug`. Output: `app/build/outputs/apk/debug/app-debug.apk`.

The included `.github/workflows/build-apk.yml` can build the APK in GitHub Actions. Upload the project contents to a repository, open Actions, run `Build DuaCafe TV APK`, then download artifact `DuaCafe-BootSplash-APK`.

## Install from phone

Download the resulting APK to iPhone and install using atvTools' APK installation feature (or `adb install` from a computer). On the TV, allow installing apps from the chosen source, if requested. Run **DuaCafé Startlogo** manually once from Apps; after 3 seconds it should go to FLauncher. Then run a **full reboot**, not just standby, to test BOOT_COMPLETED.

## Troubleshooting

- Manual test: `am start -n de.duacafe.bootsplash/.SplashActivity`
- Confirm installation: `pm list packages de.duacafe.bootsplash`
- If automatic startup doesn't occur, firmware might restrict BOOT_COMPLETED startup. Review app permission/startup settings before considering any deeper system modifications.
- Uninstall: `pm uninstall de.duacafe.bootsplash` (does not touch other apps or settings).

## Compatibility notes

This app is designed for Android 8.0 and the supplied FLauncher package name. Actual Android TV 8.x build and Philips boot-sequence behavior vary.
