# DuaCafé TV – APK erstellen

Dieses Projekt zeigt beim Start das DuaCafé-Logo für drei Sekunden und versucht dann FLauncher zu öffnen.

## GitHub Actions (ohne PC)
1. Öffne https://github.com/nohxra/DuaCafe-TV
2. Lade den **Inhalt** dieses Projektordners (nicht den äußeren ZIP-Ordner) ins Repository hoch: `app/`, `.github/workflows/build-apk.yml`, `build.gradle`, `settings.gradle`, `gradle.properties`, `README.md`.
3. Warte auf den automatischen Workflow unter **Actions > Build DuaCafe TV APK**.
4. Öffne den erfolgreichen Run, lade unter **Artifacts** `DuaCafe-BootSplash-APK` herunter und entpacke die APK.

## Installation
Installiere `app-debug.apk` auf dem Android-8-Fernseher, öffne die App einmal und teste anschließend einen vollständigen Neustart.

## Einschränkungen
Das automatische Öffnen nach dem Booten kann je nach TV-Hersteller und Android-Firmware durch Startbeschränkungen verhindert werden. FLauncher (`me.efesser.flauncher`) sollte installiert sein. Die App ersetzt nicht das originale, systemseitige Bootlogo.
